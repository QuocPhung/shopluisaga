<footer class="bg-white text-center text-sm py-4 shadow mt-6">
    &copy; {{ date('Y') }} PC Store. All rights reserved.
</footer>
