

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Quản lý đơn hàng'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-orders')): ?>
<a href="<?php echo e(route('admin.dashboard')); ?>"
       class="bg-green-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4 inline-block">
        Quay Lại
    </a>
<h1 class="text-2xl font-bold mb-4">Quản lý đơn hàng</h1>
<?php if(session('success')): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-2 rounded mb-4">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<form method="GET" class="mb-6 flex flex-wrap gap-4">
    <input type="text" name="name" placeholder="Tên" value="<?php echo e(request('name')); ?>" class="border px-2 py-1 rounded">
    <input type="text" name="email" placeholder="Email" value="<?php echo e(request('email')); ?>" class="border px-2 py-1 rounded">
    <select name="status" class="border px-2 py-1 rounded">
        <option value="">-- Trạng thái --</option>
        <option value="pending" <?php if(request('status') == 'pending'): echo 'selected'; endif; ?>>Đang xử lý</option>
        <option value="completed" <?php if(request('status') == 'completed'): echo 'selected'; endif; ?>>Đã xử lý</option>
        <option value="cancelled" <?php if(request('status') == 'cancelled'): echo 'selected'; endif; ?>>Đã hủy</option>
    </select>
    <input type="date" name="from" value="<?php echo e(request('from')); ?>" class="border px-2 py-1 rounded">
    <input type="date" name="to" value="<?php echo e(request('to')); ?>" class="border px-2 py-1 rounded">
    <button class="bg-blue-600 text-white px-4 py-1 rounded">Lọc</button>
</form>

<table class="w-full text-sm border">
    <thead>
        <tr class="bg-gray-200">
            <th class="p-2 border">Mã</th>
            <th class="p-2 border">Tên KH</th>
            <th class="p-2 border">Email</th>
            <th class="p-2 border">Tổng</th>
            <th class="p-2 border">Ngày</th>
            <th class="p-2 border">Trạng thái</th>
            <th class="p-2 border">Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="p-2 border">#<?php echo e($order->id); ?></td>
            <td class="p-2 border"><?php echo e($order->name); ?></td>
            <td class="p-2 border"><?php echo e($order->email); ?></td>
            <td class="p-2 border"><?php echo e(number_format($order->total_price)); ?>đ</td>
            <td class="p-2 border"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></td>
            <td class="p-2 border"><?php echo e(ucfirst($order->status)); ?></td>
            <td class="p-2 border">
                <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" class="text-blue-600 hover:underline">Xem</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="mt-4">
    <?php echo e($orders->withQueryString()->links()); ?>

</div>
<?php else: ?>
<?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\orders\index.blade.php ENDPATH**/ ?>