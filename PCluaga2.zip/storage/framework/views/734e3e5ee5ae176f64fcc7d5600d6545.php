

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Cập nhật sản phẩm'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-products')): ?>


<div class="max-w-4xl mx-auto bg-white p-6 rounded shadow">
    <h2 class="text-xl font-bold mb-4">Cập nhật sản phẩm</h2>

    <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="font-medium">Tên</label>
                <input type="text" name="name" value="<?php echo e(old('name', $product->name)); ?>" class="w-full border p-2 rounded">
            </div>
            <div>
                <label class="font-medium">Mã</label>
                <input type="text" value="<?php echo e($product->code); ?>" disabled class="w-full border p-2 rounded bg-gray-100">
            </div>
        </div>

        
        <div class="grid grid-cols-3 gap-4 mt-4">
            <div>
                <label>Giá gốc</label>
                <input type="number" name="price" value="<?php echo e($product->price); ?>" class="w-full border p-2 rounded">
            </div>
            <div>
                <label>Giá KM (tự tính)</label>
                <input type="text" value="<?php echo e(number_format($product->final_price)); ?> đ"
                       class="w-full border p-2 rounded bg-gray-100 text-red-600" disabled>
                <?php if($product->sales()->where('status', 1)->exists()): ?>
                    <div class="text-green-600 text-sm mt-1">
                        Đang áp dụng: <?php echo e($product->discount_text); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div>
                <label>Kho</label>
                <input type="number" name="stock" value="<?php echo e($product->stock); ?>" class="w-full border p-2 rounded">
            </div>
        </div>

        
        <div class="grid grid-cols-2 gap-4 mt-4">
            <div>
                <label>Danh mục</label>
                <select name="category_id" class="w-full border p-2 rounded">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cate->id); ?>" <?php echo e($cate->id == $product->category_id ? 'selected' : ''); ?>>
                            <?php echo e($cate->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label>Trạng thái</label>
                <select name="status" class="w-full border p-2 rounded">
                    <option value="1" <?php echo e($product->status ? 'selected' : ''); ?>>Hiển thị</option>
                    <option value="0" <?php echo e(!$product->status ? 'selected' : ''); ?>>Ẩn</option>
                </select>
            </div>
        </div>

        
        <div class="mt-4">
            <label>Mô tả</label>
            <?php if (isset($component)) { $__componentOriginal84718b01b767b68d581aa151b6a51e72 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84718b01b767b68d581aa151b6a51e72 = $attributes; } ?>
<?php $component = App\View\Components\Forms\TinymceEditor::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.tinymce-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Forms\TinymceEditor::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'description','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->description)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84718b01b767b68d581aa151b6a51e72)): ?>
<?php $attributes = $__attributesOriginal84718b01b767b68d581aa151b6a51e72; ?>
<?php unset($__attributesOriginal84718b01b767b68d581aa151b6a51e72); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84718b01b767b68d581aa151b6a51e72)): ?>
<?php $component = $__componentOriginal84718b01b767b68d581aa151b6a51e72; ?>
<?php unset($__componentOriginal84718b01b767b68d581aa151b6a51e72); ?>
<?php endif; ?>
        </div>

        
        <div class="mt-6">
            <label class="block font-medium">Ảnh mô tả</label>
            <input type="file" name="images[mo-ta][]" multiple accept="image/*" class="w-full border p-2 rounded mt-1">
        </div>

        <div class="mt-4">
            <label class="block font-medium">Ảnh kỹ thuật</label>
            <input type="file" name="images[ky-thuat][]" multiple accept="image/*" class="w-full border p-2 rounded mt-1">
        </div>

        <div class="mt-4">
            <label class="block font-medium">Ảnh thực tế</label>
            <input type="file" name="images[thuc-te][]" multiple accept="image/*" class="w-full border p-2 rounded mt-1">
        </div>

        
        <div class="mt-6">
            <label class="block font-bold text-lg mb-2">Ảnh hiện tại</label>
            <div class="grid grid-cols-4 gap-4">
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="relative border p-2 rounded shadow <?php echo e($img->is_thumbnail ? 'ring-2 ring-blue-500' : ''); ?>">
                        <img src="<?php echo e(asset('storage/' . $img->image)); ?>" class="w-full h-24 object-cover rounded">

                        <div class="mt-1 text-xs text-center italic text-gray-600">
                            <?php echo e($img->type); ?>

                        </div>

                        
                        <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST" class="text-center mt-1">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            
                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                            <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                            <input type="hidden" name="stock" value="<?php echo e($product->stock); ?>">
                            <input type="hidden" name="category_id" value="<?php echo e($product->category_id); ?>">
                            <input type="hidden" name="status" value="<?php echo e($product->status); ?>">
                            <input type="hidden" name="description" value="<?php echo e($product->description); ?>">

                            <label>
                                <input type="radio" name="thumbnail" value="<?php echo e($img->id); ?>"
                                    onchange="this.form.submit()" <?php echo e($img->is_thumbnail ? 'checked' : ''); ?>> Đại diện
                            </label>
                        </form>

                        
                        <form action="<?php echo e(route('admin.products.images.delete', $img->id)); ?>" method="POST"
                            onsubmit="return confirm('Xoá ảnh này?')" class="absolute top-0 right-0">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500 p-1 text-xl leading-none">×</button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


        
        <div class="mt-6 flex justify-between">
            <button class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Cập nhật</button>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="text-gray-600 hover:underline">Quay lại</a>
        </div>
    </form>
</div>
<?php else: ?>
<?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\products\edit.blade.php ENDPATH**/ ?>