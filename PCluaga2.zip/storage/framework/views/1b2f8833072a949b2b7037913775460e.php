

<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded p-6">
    <h1 class="text-2xl font-bold text-gray-800 mb-4"><?php echo e($product->name); ?></h1>

    <img src="<?php echo e(asset('storage/' . ($product->thumbnail->image ?? 'default.jpg'))); ?>" 
         alt="<?php echo e($product->name); ?>" 
         class="w-full max-w-md mx-auto mb-4 rounded shadow">

    <p class="text-gray-600 mb-2">
        Giá gốc: <span class="line-through"><?php echo e(number_format($product->price, 0, ',', '.')); ?>đ</span>
    </p>

    <p class="text-red-600 text-xl font-semibold mb-4">
        Giá khuyến mãi: <?php echo e(number_format($product->final_price ?? $product->price, 0, ',', '.')); ?>đ
    </p>
    <button 
        onclick="cart.addToCart({
            id: <?php echo e($product->id); ?>,
            name: '<?php echo e($product->name); ?>',
            price: <?php echo e($product->price); ?>,
            final_price: <?php echo e($product->final_price); ?>,
            image: '<?php echo e(asset('storage/' . ($product->thumbnail->image ?? 'default.jpg'))); ?>'
        })"
        class="mt-2 bg-green-600 hover:bg-green-700 text-white px-4 py-1 rounded text-sm"
    >
        Thêm vào giỏ
    </button>
    <p class="text-gray-700">
        <?php echo nl2br(e($product->description ?? 'Không có mô tả')); ?>

    </p>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.products.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\pages\products\show.blade.php ENDPATH**/ ?>