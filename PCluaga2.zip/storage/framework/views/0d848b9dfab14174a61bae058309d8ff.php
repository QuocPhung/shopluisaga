

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Gán quyền cho người dùng'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-users')): ?>


<h1 class="text-xl font-bold mb-4">Gán quyền cho người dùng: <?php echo e($user->name); ?></h1>

<form method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>" class="space-y-4 max-w-lg">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <?php
        // Xác định đây có phải là admin gốc không (tuỳ cách bạn xác định: id hoặc email)
        $isMainAdmin = $user->id === 1; // hoặc: $user->email === 'admin@example.com';
    ?>

    <?php if($isMainAdmin): ?>
        <div class="p-3 bg-yellow-100 text-yellow-800 rounded">
            Đây là tài khoản <strong>admin chính</strong>. Không thể thay đổi vai trò.
        </div>
    <?php else: ?>
        <div>
            <label class="block font-medium mb-1">Vai trò</label>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isAdminRole = $role->name === 'admin';
                    $adminExists = \App\Models\Role::where('name', 'admin')->first()?->users()->where('id', '!=', $user->id)->exists();
                ?>

                <?php if($isAdminRole && $adminExists) continue; ?>

                <label class="inline-flex items-center mr-4 mb-2">
                    <input type="checkbox" name="roles[]"
                        value="<?php echo e($role->id); ?>"
                        <?php echo e($user->roles->contains($role->id) ? 'checked' : ''); ?>>
                    <?php echo e($role->name); ?>

                </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        <?php echo e($isMainAdmin ? 'disabled' : ''); ?>>
        Cập nhật
    </button>
    <a href="<?php echo e(route('admin.users.index')); ?>" class="ml-4 text-gray-600 hover:underline">Quay lại</a>
</form>
<?php else: ?>
<?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\users\edit.blade.php ENDPATH**/ ?>