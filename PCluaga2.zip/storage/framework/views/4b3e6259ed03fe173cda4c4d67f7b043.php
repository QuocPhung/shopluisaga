

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Danh sách khuyến mãi'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-sales')): ?>


<div class="container mx-auto p-6">
    <a href="<?php echo e(route('admin.dashboard')); ?>"
       class="bg-green-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4 inline-block">
        Quay Lại
    </a>
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-semibold">Danh sách khuyến mãi</h2>
        <a href="<?php echo e(route('admin.sales.create')); ?>"
           class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">+ Thêm khuyến mãi</a>
    </div>

    
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Thành công',
                text: '<?php echo e(session('success')); ?>',
                toast: true,
                position: 'top-end',
                timer: 2500,
                showConfirmButton: false
            });
        </script>
    <?php endif; ?>

    <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-300 text-sm">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-2 border">Tên</th>
                    <th class="px-4 py-2 border">Loại</th>
                    <th class="px-4 py-2 border">Giá trị</th>
                    <th class="px-4 py-2 border">Thời gian</th>
                    <th class="px-4 py-2 border">Sản phẩm</th>
                    <th class="px-4 py-2 border">Trạng thái</th>
                    <th class="px-4 py-2 border">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t hover:bg-gray-50">
                        <td class="px-4 py-2 border"><?php echo e($sale->name); ?></td>
                        <td class="px-4 py-2 border">
                            <?php echo e($sale->discount_type == 'percent' ? 'Phần trăm' : 'Giá trị cố định'); ?>

                        </td>
                        <td class="px-4 py-2 border">
                            <?php echo e($sale->discount_value); ?> <?php echo e($sale->discount_type == 'percent' ? '%' : '₫'); ?>

                        </td>
                        <td class="px-4 py-2 border">
                            <?php echo e(\Carbon\Carbon::parse($sale->start_date)->format('d/m/Y')); ?> - 
                            <?php echo e(\Carbon\Carbon::parse($sale->end_date)->format('d/m/Y')); ?>

                        </td>
                        <td class="px-4 py-2 border">
                            <?php echo e($sale->products->count()); ?> sp
                        </td>
                        <td class="px-4 py-2 border">
                            <?php if($sale->status): ?>
                                <span class="text-green-600 font-semibold">Hiển thị</span>
                            <?php else: ?>
                                <span class="text-gray-500 italic">Ẩn</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2 border text-center whitespace-nowrap">
                            <a href="<?php echo e(route('admin.sales.edit', $sale->id)); ?>"
                               class="text-yellow-600 hover:underline mr-2">Sửa</a>
                            <form action="<?php echo e(route('admin.sales.destroy', $sale->id)); ?>" method="POST"
                                  onsubmit="return confirm('Xóa khuyến mãi này?')" class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline">Xóa</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        <div class="mt-4">
            <?php echo e($sales->links('pagination::tailwind')); ?>

        </div>
    </div>
</div>
<?php else: ?>
    <?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\sales\index.blade.php ENDPATH**/ ?>