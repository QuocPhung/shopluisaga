

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Thêm sản phẩm'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-products')): ?>



<div class="max-w-4xl mx-auto bg-white p-6 rounded shadow">
    <h2 class="text-xl font-bold mb-6">Thêm sản phẩm</h2>

    <form action="<?php echo e(route('admin.products.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        
        <div class="mb-4">
            <label class="block font-medium">Tên sản phẩm</label>
            <input type="text" name="name" class="w-full border p-2 rounded" required>
        </div>

        
        <div class="mb-4">
            <label class="block font-medium">Mã sản phẩm</label>
            <input type="text" name="code" class="w-full border p-2 rounded" required>
        </div>

        
        <div class="grid grid-cols-3 gap-4 mb-4">
            <div>
                <label class="block font-medium">Giá gốc</label>
                <input type="number" name="price" class="w-full border p-2 rounded" required>
            </div>
            <div>
                <label class="block font-medium">Giá KM (tự tính nếu có khuyến mãi)</label>
                <input type="text" class="w-full border p-2 rounded bg-gray-100 text-red-600" 
                    value="Sẽ tự động tính sau khi gán khuyến mãi" disabled>
            </div>
            <div>
                <label class="block font-medium">Kho</label>
                <input type="number" name="stock" class="w-full border p-2 rounded" required>
            </div>
        </div>

        
        <div class="mb-4">
            <label class="block font-medium">Danh mục</label>
            <select name="category_id" class="w-full border p-2 rounded" required>
                <option value="">-- Chọn danh mục --</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-4">
            <label class="block font-medium">Trạng thái</label>
            <select name="status" class="w-full border p-2 rounded">
                <option value="1">Hiển thị</option>
                <option value="0">Ẩn</option>
            </select>
        </div>

        
        <div class="mb-4">
            <label class="block font-medium mb-1">Mô tả sản phẩm</label>
            <?php if (isset($component)) { $__componentOriginal84718b01b767b68d581aa151b6a51e72 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84718b01b767b68d581aa151b6a51e72 = $attributes; } ?>
<?php $component = App\View\Components\Forms\TinymceEditor::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.tinymce-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Forms\TinymceEditor::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'description']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84718b01b767b68d581aa151b6a51e72)): ?>
<?php $attributes = $__attributesOriginal84718b01b767b68d581aa151b6a51e72; ?>
<?php unset($__attributesOriginal84718b01b767b68d581aa151b6a51e72); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84718b01b767b68d581aa151b6a51e72)): ?>
<?php $component = $__componentOriginal84718b01b767b68d581aa151b6a51e72; ?>
<?php unset($__componentOriginal84718b01b767b68d581aa151b6a51e72); ?>
<?php endif; ?>
        </div>

        <div class="mt-6">
            <label class="block font-medium">Ảnh mô tả</label>
            <input type="file" name="images[mo-ta][]" multiple accept="image/*" class="w-full border p-2 rounded mt-1">
        </div>

        <div class="mt-4">
            <label class="block font-medium">Ảnh kỹ thuật</label>
            <input type="file" name="images[ky-thuat][]" multiple accept="image/*" class="w-full border p-2 rounded mt-1">
        </div>

        <div class="mt-4">
            <label class="block font-medium">Ảnh thực tế</label>
            <input type="file" name="images[thuc-te][]" multiple accept="image/*" class="w-full border p-2 rounded mt-1">
        </div>

        
        <div class="mb-6">
            <label class="block font-medium mb-2">Thông số kỹ thuật</label>
            <div id="attribute-list" class="space-y-2">
                <div class="flex gap-2">
                    <input type="text" name="attributes[0][name]" placeholder="Tên thuộc tính (VD: CPU)" class="w-1/2 border p-2 rounded">
                    <input type="text" name="attributes[0][value]" placeholder="Giá trị (VD: Intel i5-12400F)" class="w-1/2 border p-2 rounded">
                </div>
            </div>
            <button type="button" onclick="addAttribute()" class="mt-2 text-blue-600 hover:underline text-sm">+ Thêm thuộc tính</button>
        </div>

        
        <div class="mt-6 flex justify-between">
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Thêm</button>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="text-gray-600 hover:underline">Quay lại</a>
        </div>
    </form>
</div>
<?php else: ?>
<?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php if (isset($component)) { $__componentOriginal64ae506d51b70549a46b57e3bed1687c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal64ae506d51b70549a46b57e3bed1687c = $attributes; } ?>
<?php $component = App\View\Components\Head\TinymceConfig::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('head.tinymce-config'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Head\TinymceConfig::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal64ae506d51b70549a46b57e3bed1687c)): ?>
<?php $attributes = $__attributesOriginal64ae506d51b70549a46b57e3bed1687c; ?>
<?php unset($__attributesOriginal64ae506d51b70549a46b57e3bed1687c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64ae506d51b70549a46b57e3bed1687c)): ?>
<?php $component = $__componentOriginal64ae506d51b70549a46b57e3bed1687c; ?>
<?php unset($__componentOriginal64ae506d51b70549a46b57e3bed1687c); ?>
<?php endif; ?>

    <script>
        let attributeIndex = 1;
        function addAttribute() {
            const container = document.getElementById('attribute-list');
            const div = document.createElement('div');
            div.classList.add('flex', 'gap-2', 'mt-1');
            div.innerHTML = `
                <input type="text" name="attributes[${attributeIndex}][name]" placeholder="Tên thuộc tính" class="w-1/2 border p-2 rounded">
                <input type="text" name="attributes[${attributeIndex}][value]" placeholder="Giá trị" class="w-1/2 border p-2 rounded">
            `;
            container.appendChild(div);
            attributeIndex++;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\products\create.blade.php ENDPATH**/ ?>