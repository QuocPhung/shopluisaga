<?php if($mainBanners->isNotEmpty()): ?>
<div 
    x-data="{ current: 0 }" 
    x-init="setInterval(() => current = (current + 1) % <?php echo e($mainBanners->count()); ?>, 5000)" 
    class="relative w-full h-[380px] overflow-hidden rounded shadow"
>
    <div class="flex transition-transform duration-700 ease-in-out w-full h-full"
        :style="`transform: translateX(-${current * 100}%)`"
    >
        <?php $__currentLoopData = $mainBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w-full h-full flex-shrink-0">
                <a href="<?php echo e($banner->link ?? '#'); ?>" target="_blank" class="block w-full h-full">
                    <img src="<?php echo e(asset('storage/' . $banner->image)); ?>"
                         alt="<?php echo e($banner->title); ?>"
                         class="w-full h-full object-cover">
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
        <?php $__currentLoopData = $mainBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button 
                class="w-3 h-3 rounded-full transition-colors duration-300"
                :class="current === <?php echo e($i); ?> ? 'bg-white' : 'bg-white/50'"
                @click="current = <?php echo e($i); ?>"
            ></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\layouts\partials\banner-main.blade.php ENDPATH**/ ?>