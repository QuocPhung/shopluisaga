

<?php $__env->startSection('title', 'Chỉnh sửa đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-bold mb-6">Chỉnh sửa đơn hàng #<?php echo e($order->id); ?></h1>

<form method="POST" action="<?php echo e(route('orders.update', $order)); ?>" class="space-y-4">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div>
        <label class="block font-semibold">Tên người nhận</label>
        <input type="text" name="name" value="<?php echo e(old('name', $order->name)); ?>" class="form-input w-full">
    </div>

    <div>
        <label class="block font-semibold">Email người nhận</label>
        <input type="text" name="email" value="<?php echo e(old('email', $order->email)); ?>" class="form-input w-full">
    </div>

    <div>
        <label class="block font-semibold">Số điện thoại</label>
        <input type="text" name="phone" value="<?php echo e(old('phone', $order->phone)); ?>" class="form-input w-full">
    </div>

    <div>
        <label class="block font-semibold">Địa chỉ</label>
        <textarea name="address" class="form-textarea w-full"><?php echo e(old('address', $order->address)); ?></textarea>
    </div>

    <div>
        <label class="block font-semibold">Phương thức thanh toán</label>
        <select name="payment_method" class="form-select w-full">
            <option value="cod" <?php if(old('payment_method', $order->payment_method) === 'cod'): echo 'selected'; endif; ?>>Thanh toán khi nhận hàng</option>
            <option value="bank" <?php if(old('payment_method', $order->payment_method) === 'bank'): echo 'selected'; endif; ?>>Chuyển khoản</option>
        </select>
    </div>

    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Cập nhật</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.cart.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\pages\orders\edit.blade.php ENDPATH**/ ?>