<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'name' => 'description',   // Tên field mặc định là "description"
    'value' => '',             // Nội dung mặc định
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'name' => 'description',   // Tên field mặc định là "description"
    'value' => '',             // Nội dung mặc định
]); ?>
<?php foreach (array_filter(([
    'name' => 'description',   // Tên field mặc định là "description"
    'value' => '',             // Nội dung mặc định
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<textarea name="<?php echo e($name); ?>" class="tinymce w-full border rounded p-2" rows="10">
    <?php echo e(old($name, $value)); ?>

</textarea>
<?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\components\forms\tinymce-editor.blade.php ENDPATH**/ ?>