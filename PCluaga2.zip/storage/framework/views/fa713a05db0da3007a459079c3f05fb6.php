<footer class="bg-white text-center text-sm py-4 shadow mt-6">
    &copy; <?php echo e(date('Y')); ?> PC Store. All rights reserved.
</footer>
<?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\layouts\partials\footer.blade.php ENDPATH**/ ?>