<?php if($banners->count() > 3): ?>
    <div class="flex-1 flex flex-col justify-between h-full">
        <?php $__currentLoopData = $banners->skip(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($banner->link ?? '#'); ?>" class="block">
                <div class="aspect-[16/9] w-full rounded overflow-hidden shadow">
                    <img src="<?php echo e(asset('storage/' . $banner->image)); ?>"
                         alt="<?php echo e($banner->title); ?>"
                         class="w-full h-full object-cover mb-2">
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\layouts\partials\banner-side.blade.php ENDPATH**/ ?>