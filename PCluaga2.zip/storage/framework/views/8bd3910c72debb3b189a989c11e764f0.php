<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Giỏ hàng'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script>
        window.userLoggedIn = <?php echo json_encode(auth()->check(), 15, 512) ?>;
    </script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>
<body class="bg-gray-100 text-gray-800 min-h-screen flex flex-col">

    
    <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <main class="flex-grow container mx-auto px-4 py-6">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\pages\cart\cart.blade.php ENDPATH**/ ?>