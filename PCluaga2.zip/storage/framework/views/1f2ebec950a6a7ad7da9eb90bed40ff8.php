

<?php $__env->startSection('title', 'Đơn hàng của tôi'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="text-2xl font-bold mb-6">Lịch sử đơn hàng</h2>

    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white p-4 shadow rounded mb-4">
            <div class="flex justify-between">
                <div>
                    <p><strong>Mã đơn:</strong> #<?php echo e($order->id); ?></p>
                    <p><strong>Tổng tiền:</strong> <?php echo e(number_format($order->total_price)); ?> đ</p>
                    <p><strong>Phương thức:</strong> <?php echo e($order->payment_method === 'cod' ? 'COD' : 'Chuyển khoản'); ?></p>
                    <p><strong>Ngày đặt:</strong> <?php echo e($order->created_at->format('d/m/Y H:i')); ?></p>
                    <p><strong>Trạng thái</strong> <?php echo e($order->status === 'pending' ? 'Đang chờ xử lý' : ($order->status === 'cancelled' ? 'Đã hủy' : 'Đã xử lý')); ?></p>
                </div>
                <div>
                    <a href="<?php echo e(route('orders.show', $order)); ?>" class="text-blue-500 hover:underline">Chi tiết</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-gray-500 italic">Bạn chưa đặt đơn hàng nào.</p>
    <?php endif; ?>

    <div class="mt-4">
        <?php echo e($orders->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.cart.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\pages\orders\index.blade.php ENDPATH**/ ?>