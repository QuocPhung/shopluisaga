

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Thống kê doanh thu'); ?>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-revenue')): ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>"
       class="bg-green-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4 inline-block">
        Quay Lại
    </a>
<h1 class="text-2xl font-bold mb-4">Thống kê doanh thu</h1>

<form method="GET" class="flex gap-4 mb-6">
    <div>
        <label>Từ ngày:</label>
        <input type="date" name="from" value="<?php echo e($from); ?>" class="border p-2 rounded">
    </div>
    <div>
        <label>Đến ngày:</label>
        <input type="date" name="to" value="<?php echo e($to); ?>" class="border p-2 rounded">
    </div>
    <div class="flex items-end">
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Lọc</button>
    </div>
</form>

<div class="bg-white p-4 rounded shadow mb-6">
    <p><strong>Tổng đơn hàng:</strong> <?php echo e($totalOrders); ?></p>
    <p><strong>Tổng doanh thu:</strong> <?php echo e(number_format($totalRevenue)); ?> đ</p>
</div>

<table class="w-full text-sm border">
    <thead class="bg-gray-100">
        <tr>
            <th class="p-2 border">Ngày</th>
            <th class="p-2 border">Doanh thu</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dailyRevenue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="p-2 border"><?php echo e(\Carbon\Carbon::parse($day->date)->format('d/m/Y')); ?></td>
                <td class="p-2 border"><?php echo e(number_format($day->total)); ?> đ</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\revenue\index.blade.php ENDPATH**/ ?>