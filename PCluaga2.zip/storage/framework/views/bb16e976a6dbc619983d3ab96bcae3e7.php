

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Quản lý người dùng'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-users')): ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>"
       class="bg-green-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4 inline-block">
        Quay Lại
    </a>
<h1 class="text-2xl font-bold mb-4">Quản lý người dùng</h1>

<table class="w-full border text-sm">
    <thead>
        <tr class="bg-gray-100">
            <th class="p-2 border">Tên</th>
            <th class="p-2 border">Email</th>
            <th class="p-2 border">Quyền</th>
            <th class="p-2 border">Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="p-2 border"><?php echo e($user->name); ?></td>
            <td class="p-2 border"><?php echo e($user->email); ?></td>
            <td class="p-2 border">
                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mr-1"><?php echo e($role->name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td class="p-2 border">
                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="text-blue-600 hover:underline">Sửa</a>
                <?php if(auth()->id() !== $user->id): ?>
                <form method="POST" action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" class="inline" onsubmit="return confirm('Xóa người dùng này?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="text-red-600 hover:underline ml-2">Xóa</button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="mt-4">
    <?php echo e($users->links()); ?>

</div>
<?php else: ?>
<?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\users\index.blade.php ENDPATH**/ ?>