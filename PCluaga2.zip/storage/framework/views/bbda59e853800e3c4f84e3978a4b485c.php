

<?php $__env->startSection('title', 'Trang chủ'); ?>

<?php $__env->startSection('content'); ?>
<?php if($discountedProducts->count()): ?>
<section class="mb-8" x-data="{ showAll: false }">
    <h2 class="text-xl font-bold mb-4 text-blue-600">Sản phẩm khuyến mãi</h2>
    
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <?php $__currentLoopData = $discountedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div 
                class="bg-white shadow rounded p-4 hover:shadow-lg transition" 
                x-show="showAll || <?php echo e($index); ?> < 4"
                x-transition
            >
                <img src="<?php echo e(asset('storage/' . ($product->thumbnail->image ?? 'default.jpg'))); ?>" 
                     alt="<?php echo e($product->name); ?>" 
                     class="w-full h-40 object-cover rounded mb-2">

                <h3 class="font-semibold text-gray-800"><?php echo e($product->name); ?></h3>

                <?php if($product->final_price < $product->price): ?>
                    <p class="text-sm text-gray-600 line-through">
                        <?php echo e(number_format($product->price, 0, ',', '.')); ?>đ
                    </p>
                    <p class="text-red-500 font-bold text-lg">
                        <?php echo e(number_format($product->final_price, 0, ',', '.')); ?>đ
                    </p>
                    <p class="text-sm text-green-600 italic">
                        <?php echo e($product->sale_name); ?> – <?php echo e($product->sale_status_label); ?>

                    </p>
                <?php else: ?>
                    <p class="text-gray-800 font-bold text-lg">
                        <?php echo e(number_format($product->price, 0, ',', '.')); ?>đ
                    </p>
                <?php endif; ?>
                    <button 
                        onclick="cart.addToCart({
                            id: <?php echo e($product->id); ?>,
                            name: '<?php echo e($product->name); ?>',
                            price: <?php echo e($product->price); ?>,
                            final_price: <?php echo e($product->final_price); ?>,
                            image: '<?php echo e(asset('storage/' . ($product->thumbnail->image ?? 'default.jpg'))); ?>'
                        })"
                        class="mt-2 bg-green-600 hover:bg-green-700 text-white px-4 py-1 rounded text-sm"
                    >
                        Thêm vào giỏ
                    </button>
                <a href="<?php echo e(route('product.show', $product->id)); ?>"
                   class="mt-2 inline-block bg-blue-600 text-white px-4 py-1 rounded text-sm">Xem chi tiết</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if($discountedProducts->count() > 4): ?>
        <div class="text-center mt-4">
            <a href="<?php echo e(route('product.sale')); ?>" class="text-blue-600 font-semibold hover:underline">
                Xem thêm →
            </a>
        </div>
    <?php endif; ?>
</section>
<?php endif; ?>

<?php if($categoriesWithProducts->count()): ?>
    <?php $__currentLoopData = $categoriesWithProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section class="mb-10">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-blue-600"><?php echo e($category->name); ?></h2>
                <a href="<?php echo e(route('category.show', $category->id)); ?>" class="text-sm text-blue-500 hover:underline">
                    Xem tất cả →
                </a>
            </div>

            <?php if($category->allProducts->count()): ?>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <?php $__currentLoopData = $category->allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white shadow rounded p-4 hover:shadow-lg transition">
                            <img src="<?php echo e(asset('storage/' . ($product->thumbnail->image ?? 'default.jpg'))); ?>"
                                 alt="<?php echo e($product->name); ?>"
                                 class="w-full h-40 object-cover rounded mb-2">

                            <h3 class="font-semibold text-gray-800 truncate"><?php echo e($product->name); ?></h3>

                            <?php if($product->final_price < $product->price): ?>
                                <p class="text-sm text-gray-600 line-through">
                                    <?php echo e(number_format($product->price, 0, ',', '.')); ?>đ
                                </p>
                                <p class="text-red-500 font-bold text-lg">
                                    <?php echo e(number_format($product->final_price, 0, ',', '.')); ?>đ
                                </p>
                            <?php else: ?>
                                <p class="text-gray-800 font-bold text-lg">
                                    <?php echo e(number_format($product->price, 0, ',', '.')); ?>đ
                                </p>
                            <?php endif; ?>
                            <button 
                                onclick="cart.addToCart({
                                    id: <?php echo e($product->id); ?>,
                                    name: '<?php echo e($product->name); ?>',
                                    price: <?php echo e($product->price); ?>,
                                    final_price: <?php echo e($product->final_price); ?>,
                                    image: '<?php echo e(asset('storage/' . ($product->thumbnail->image ?? 'default.jpg'))); ?>'
                                })"
                                class="mt-2 bg-green-600 hover:bg-green-700 text-white px-4 py-1 rounded text-sm"
                            >
                                Thêm vào giỏ
                            </button>

                            <a href="<?php echo e(route('product.show', $product->id)); ?>"
                               class="mt-2 inline-block bg-blue-600 text-white px-4 py-1 rounded text-sm">Xem chi tiết</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="text-gray-500 italic">Chưa có sản phẩm trong danh mục này.</p>
            <?php endif; ?>
        </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\pages\home.blade.php ENDPATH**/ ?>