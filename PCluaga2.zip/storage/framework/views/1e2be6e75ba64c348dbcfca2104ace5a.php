<!-- resources/views/admin/index.blade.php -->


<?php $__env->startSection('title', 'Bảng điều khiển'); ?>

<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-dashboard')): ?>
    <h1 class="text-2xl font-bold mb-4">Chào mừng <?php echo e(auth()->user()->name); ?> đến trang quản trị!</h1>

    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-categories')): ?>
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="block p-4 bg-white shadow rounded hover:bg-gray-100">
            📁 Quản lý Danh mục
        </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-products')): ?>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="block p-4 bg-white shadow rounded hover:bg-gray-100">
            🖼 Quản lý Sản phẩm
        </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-sales')): ?>
        <a href="<?php echo e(route('admin.sales.index')); ?>" class="block p-4 bg-white shadow rounded hover:bg-gray-100">
            🎁 Quản lý Khuyến Mãi
        </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-banners')): ?>
        <a href="<?php echo e(route('admin.banners.index')); ?>" class="block p-4 bg-white shadow rounded hover:bg-gray-100">
            🖼 Quản lý Banner
        </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-orders')): ?>
        <a href="<?php echo e(route('admin.orders.index')); ?>" class="block p-4 bg-white shadow rounded hover:bg-gray-100">
            🖼 Quản lý Order
        </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-revenue')): ?>
        <a href="<?php echo e(route('admin.revenue.index')); ?>" class="block p-4 bg-white shadow rounded hover:bg-gray-100">
            📈 Quản lý Doanh thu
        </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-users')): ?>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="block p-4 bg-white shadow rounded hover:bg-gray-100">
            👤 Quản lý Người dùng
        </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-reports')): ?>
        <a href="<?php echo e(route('admin.reports.index')); ?>" class="block p-4 bg-white shadow rounded hover:bg-gray-100">
            📊 Quản lý Báo cáo
        </a>
        <?php endif; ?>
    </div>
<?php else: ?>
    <?php abort(403); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>