

<?php $__env->startSection('title', $selectedCategory->name ?? 'Tất cả sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4 text-blue-600">
        <?php echo e($selectedCategory->name ?? 'Tất cả sản phẩm'); ?>

    </h1>

    <?php if($products->count()): ?>
        <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white shadow rounded p-4 hover:shadow-lg transition">
                    <img src="<?php echo e(asset('storage/' . ($product->thumbnail->image ?? 'default.jpg'))); ?>"
                         alt="<?php echo e($product->name); ?>"
                         class="w-full h-40 object-cover rounded mb-2">

                    <h3 class="font-semibold text-gray-800 truncate"><?php echo e($product->name); ?></h3>

                    <?php if($product->final_price < $product->price): ?>
                        <p class="text-sm text-gray-600 line-through">
                            <?php echo e(number_format($product->price, 0, ',', '.')); ?>đ
                        </p>
                        <p class="text-red-500 font-bold text-lg">
                            <?php echo e(number_format($product->final_price, 0, ',', '.')); ?>đ
                        </p>
                    <?php else: ?>
                        <p class="text-gray-800 font-bold text-lg">
                            <?php echo e(number_format($product->price, 0, ',', '.')); ?>đ
                        </p>
                    <?php endif; ?>
                    <button 
                        onclick="cart.addToCart({
                            id: <?php echo e($product->id); ?>,
                            name: '<?php echo e($product->name); ?>',
                            price: <?php echo e($product->price); ?>,
                            final_price: <?php echo e($product->final_price); ?>,
                            image: '<?php echo e(asset('storage/' . ($product->thumbnail->image ?? 'default.jpg'))); ?>'
                        })"
                        class="mt-2 bg-green-600 hover:bg-green-700 text-white px-4 py-1 rounded text-sm"
                    >
                        Thêm vào giỏ
                    </button>

                    <a href="<?php echo e(route('product.show', $product->id)); ?>"
                       class="mt-2 inline-block bg-blue-600 text-white px-4 py-1 rounded text-sm">Xem chi tiết</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-6">
            <?php echo e($products->links()); ?>

        </div>
    <?php else: ?>
        <p class="text-gray-500 italic">Không có sản phẩm nào.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.products.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\pages\products\index.blade.php ENDPATH**/ ?>