

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Chi tiết đơn hàng'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-orders')): ?>




<h1 class="text-2xl font-bold mb-4">Chi tiết đơn hàng #<?php echo e($order->id); ?></h1>

<div class="mb-4 space-y-1">
    <p><strong>Khách hàng:</strong> <?php echo e($order->name); ?> (<?php echo e($order->email); ?>)</p>
    <p><strong>Điện thoại:</strong> <?php echo e($order->phone); ?></p>
    <p><strong>Địa chỉ:</strong> <?php echo e($order->address); ?></p>
    <p><strong>Phương thức thanh toán:</strong> <?php echo e($order->payment_method === 'cod' ? 'COD' : 'Chuyển khoản'); ?></p>
    <p><strong>Thời gian đặt:</strong> <?php echo e($order->created_at->format('d/m/Y H:i')); ?></p>
</div>

<table class="w-full text-sm border mb-6">
    <thead>
        <tr class="bg-gray-100">
            <th class="p-2 border">Sản phẩm</th>
            <th class="p-2 border">SL</th>
            <th class="p-2 border">Đơn giá</th>
            <th class="p-2 border">Thành tiền</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="p-2 border"><?php echo e($item->product->name); ?></td>
            <td class="p-2 border"><?php echo e($item->quantity); ?></td>
            <td class="p-2 border"><?php echo e(number_format($item->price)); ?> đ</td>
            <td class="p-2 border"><?php echo e(number_format($item->price * $item->quantity)); ?> đ</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="text-right text-lg font-bold mb-6">
    Tổng: <?php echo e(number_format($order->total_price)); ?> đ
</div>


<form method="POST" action="<?php echo e(route('admin.orders.updateStatus', $order->id)); ?>" class="max-w-sm space-y-3">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>

    <label class="font-medium">Trạng thái đơn hàng</label>
    <select name="status" class="border px-3 py-2 rounded w-full">
        <option value="pending" <?php if($order->status === 'pending'): echo 'selected'; endif; ?>>Đang chờ xử lý</option>
        <option value="completed" <?php if($order->status === 'completed'): echo 'selected'; endif; ?>>Đã xử lý</option>
        <option value="cancelled" <?php if($order->status === 'cancelled'): echo 'selected'; endif; ?>>Đã hủy</option>
    </select>

    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        Cập nhật trạng thái
    </button>
</form>
<?php else: ?>
    <?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\orders\show.blade.php ENDPATH**/ ?>