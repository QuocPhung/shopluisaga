<?php if(isset($categories)): ?>
    <ul class="space-y-1">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li x-data="{ open: false }" class="relative group">
                <div class="flex items-center justify-between hover:bg-blue-100 px-3 py-2 rounded"
                     @mouseenter="open = true" @mouseleave="open = false">
                        <a href="<?php echo e(route('product.index', ['category_id' => $cat->id])); ?>"
                        class="font-medium text-gray-800 flex-grow cursor-pointer">
                            <?php echo e($cat->name); ?>

                        </a>


                    <?php if($cat->childrenRecursive->isNotEmpty()): ?>
                        <svg :class="{ 'rotate-90': open }"
                             class="w-4 h-4 text-gray-400 transform transition-transform duration-200"
                             fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M9 5l7 7-7 7" />
                        </svg>
                    <?php endif; ?>
                </div>

                
                <?php if($cat->childrenRecursive->isNotEmpty()): ?>
                    <div x-show="open" x-transition
                         class="absolute top-0 left-full ml-1 bg-white border shadow rounded w-48 z-50"
                         @mouseenter="open = true" @mouseleave="open = false">
                        <?php echo $__env->make('layouts.components.category-menu', [
                            'categories' => $cat->childrenRecursive->filter(fn($child) => $child->id !== $cat->id)
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\layouts\components\category-menu.blade.php ENDPATH**/ ?>