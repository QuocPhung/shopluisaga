<h2 class="text-lg font-bold mb-4 border-b pb-2">Danh mục sản phẩm</h2>

<?php if(isset($sidebarCategories)): ?>
    <?php
        $limit = 5;
        $topCategories = $sidebarCategories->take($limit);
        $remainingCategories = $sidebarCategories->slice($limit);
    ?>

    <div x-data="{ expanded: false }" class="flex-grow relative">
        <div class="transition-all duration-300 ease-in-out space-y-1">
            
            <?php echo $__env->make('layouts.components.category-menu', [
                'categories' => $topCategories
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            <div x-show="expanded" x-collapse>
                <?php echo $__env->make('layouts.components.category-menu', [
                    'categories' => $remainingCategories
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        
        <?php if($sidebarCategories->count() > $limit): ?>
            <div class="text-center mt-4">
                <button @click="expanded = !expanded"
                        class="text-sm text-blue-600 hover:underline focus:outline-none">
                    <span x-show="!expanded">Xem thêm...</span>
                    <span x-show="expanded">Thu gọn</span>
                </button>
            </div>
        <?php endif; ?>
    </div>
<?php else: ?>
    <p class="text-sm text-gray-500 italic">Không có danh mục nào.</p>
<?php endif; ?>
<?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\layouts\partials\sidebar.blade.php ENDPATH**/ ?>