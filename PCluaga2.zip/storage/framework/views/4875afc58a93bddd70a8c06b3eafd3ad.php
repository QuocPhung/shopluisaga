<!-- resources/views/layouts/admin.blade.php -->
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Quản trị'); ?></title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

    <nav class="bg-blue-600 p-4 text-white flex justify-between">
        <div><a href="<?php echo e(route('admin.dashboard')); ?>">🛠 Luisaga Admin</a></div>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="bg-red-500 px-3 py-1 rounded hover:bg-red-600">Đăng xuất</button>
        </form>
    </nav>

    <main class="p-6">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php if (isset($component)) { $__componentOriginal64ae506d51b70549a46b57e3bed1687c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal64ae506d51b70549a46b57e3bed1687c = $attributes; } ?>
<?php $component = App\View\Components\Head\TinymceConfig::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('head.tinymce-config'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Head\TinymceConfig::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal64ae506d51b70549a46b57e3bed1687c)): ?>
<?php $attributes = $__attributesOriginal64ae506d51b70549a46b57e3bed1687c; ?>
<?php unset($__attributesOriginal64ae506d51b70549a46b57e3bed1687c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64ae506d51b70549a46b57e3bed1687c)): ?>
<?php $component = $__componentOriginal64ae506d51b70549a46b57e3bed1687c; ?>
<?php unset($__componentOriginal64ae506d51b70549a46b57e3bed1687c); ?>
<?php endif; ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\layout.blade.php ENDPATH**/ ?>