

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Thống kê doanh thu'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-reports')): ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>"
       class="bg-green-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4 inline-block">
        Quay Lại
    </a>
<h1 class="text-2xl font-bold mb-6">Biểu đồ doanh thu theo ngày</h1>


<form method="GET" class="flex items-end gap-4 mb-6">
    <div>
        <label class="block font-medium mb-1">Từ ngày</label>
        <input type="date" name="from" value="<?php echo e(request('from')); ?>" class="border rounded p-2">
    </div>
    <div>
        <label class="block font-medium mb-1">Đến ngày</label>
        <input type="date" name="to" value="<?php echo e(request('to')); ?>" class="border rounded p-2">
    </div>
    <div>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Lọc
        </button>
    </div>
</form>

<canvas id="revenueChart" height="100"></canvas>
<h2 class="text-lg font-bold mb-3">Top 10 sản phẩm bán chạy (<?php echo e($from); ?> – <?php echo e($to); ?>)</h2>

<table class="w-full text-sm border mb-12">
    <thead>
        <tr class="bg-gray-100">
            <th class="p-2 border">Sản phẩm</th>
            <th class="p-2 border">Số lượng đã bán</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="p-2 border"><?php echo e($item->product->name ?? 'Đã xóa'); ?></td>
                <td class="p-2 border"><?php echo e($item->total_sold); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="2" class="text-center text-gray-500 p-4">Không có dữ liệu</td></tr>
        <?php endif; ?>
    </tbody>
</table>
<?php else: ?>
    <?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('revenueChart').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                label: 'Doanh thu (VNĐ)',
                data: <?php echo json_encode($data); ?>,
                fill: true,
                backgroundColor: 'rgba(59, 130, 246, 0.2)',
                borderColor: 'rgba(59, 130, 246, 1)',
                tension: 0.3
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + ' đ';
                        }
                    }
                }
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\reports\index.blade.php ENDPATH**/ ?>