

<?php $__env->startSection('title', 'Thanh toán'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-4">Thông tin thanh toán</h1>

<form action="<?php echo e(route('checkout.store')); ?>" method="POST" class="space-y-4">
    <?php echo csrf_field(); ?>
    <div>
        <label for="name">Họ tên:</label>
        <input type="text" name="name" id="name" required class="w-full border p-2 rounded" value="<?php echo e(auth()->user()->name); ?>">
    </div>

    <div>
        <label for="email">Email:</label>
        <input type="email" name="email" required class="input-class" placeholder="Email của bạn">
    </div>

    <div>
        <label for="phone">Số điện thoại:</label>
        <input type="text" name="phone" id="phone" required class="w-full border p-2 rounded">
    </div>

    <div>
        <label for="address">Địa chỉ:</label>
        <textarea name="address" id="address" required class="w-full border p-2 rounded"></textarea>
    </div>

    <div>
        <label>Hình thức thanh toán:</label>
        <select name="payment_method" required class="w-full border p-2 rounded">
            <option value="cod">Thanh toán khi nhận hàng (COD)</option>
            <option value="bank_transfer">Chuyển khoản</option>
        </select>
    </div>

    <div class="text-right">
        <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">Xác nhận đặt hàng</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.cart.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\pages\checkout\create.blade.php ENDPATH**/ ?>