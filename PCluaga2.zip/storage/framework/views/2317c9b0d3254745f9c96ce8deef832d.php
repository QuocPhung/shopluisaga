

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Quản lý sản phẩm'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-products')): ?>


<div class="container mx-auto p-6">

    
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Thành công',
                text: '<?php echo e(session('success')); ?>',
                toast: true,
                position: 'top-end',
                timer: 2500,
                showConfirmButton: false
            });
        </script>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.dashboard')); ?>"
       class="bg-green-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4 inline-block">
        Quay Lại
    </a>

    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-semibold">Danh sách sản phẩm</h2>
        <a href="<?php echo e(route('admin.products.create')); ?>"
           class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            + Thêm sản phẩm
        </a>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-300 text-sm">
            <thead class="bg-gray-200">
                <tr>
                    <th class="px-4 py-2 border">Ảnh</th>
                    <th class="px-4 py-2 border">Tên sản phẩm</th>
                    <th class="px-4 py-2 border">Mã</th>
                    <th class="px-4 py-2 border">Giá</th>
                    <th class="px-4 py-2 border">Kho</th>
                    <th class="px-4 py-2 border">Danh mục</th>
                    <th class="px-4 py-2 border">Trạng thái</th>
                    <th class="px-4 py-2 border">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t hover:bg-gray-50">
                        <td class="px-2 py-2 border text-center">
                            <?php if($product->thumbnail): ?>
                                <img src="<?php echo e(asset('storage/' . $product->thumbnail->image)); ?>" alt="" class="h-12 mx-auto object-cover rounded">
                            <?php else: ?>
                                <span class="text-gray-400 italic">Không ảnh</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2 border">
                            <div class="flex items-center gap-2">
                                <span><?php echo e($product->name); ?></span>
                                <?php if($product->final_price < $product->price): ?>
                                    <span class="text-xs bg-red-600 text-white px-2 py-0.5 rounded-full">SALE</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="px-4 py-2 border"><?php echo e($product->code); ?></td>
                        <td class="px-4 py-2 border text-center">
                            <?php if($product->final_price < $product->price): ?>
                                <div class="text-red-600 font-semibold"><?php echo e(number_format($product->final_price)); ?> đ</div>
                                <div class="line-through text-sm text-gray-500"><?php echo e(number_format($product->price)); ?> đ</div>
                                <div class="text-xs text-blue-500"><?php echo e($product->discount_text); ?></div>
                            <?php else: ?>
                                <div><?php echo e(number_format($product->price)); ?> đ</div>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2 border text-center"><?php echo e($product->stock); ?></td>
                        <td class="px-4 py-2 border"><?php echo e($product->category->name ?? 'Không có'); ?></td>
                        <td class="px-4 py-2 border">
                            <?php if($product->status): ?>
                                <span class="text-green-600 font-semibold">Hiển thị</span>
                            <?php else: ?>
                                <span class="text-gray-500 italic">Ẩn</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2 border text-center whitespace-nowrap">
                            <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>"
                               class="text-yellow-600 hover:underline mr-2">Sửa</a>
                            <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>"
                                  method="POST" class="inline-block"
                                  onsubmit="return confirm('Bạn có chắc chắn muốn xóa?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline">Xóa</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        <div class="mt-4">
            <?php echo e($products->links('pagination::tailwind')); ?>

        </div>
    </div>
</div>
<?php else: ?>
<?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\products\index.blade.php ENDPATH**/ ?>