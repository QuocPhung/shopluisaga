

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Quản lý Banner'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-banners')): ?>


<div class="container mx-auto p-6">
    <a href="<?php echo e(route('admin.dashboard')); ?>"
           class="bg-green-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Quay Lại
    </a>
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-bold">Danh sách banner</h2>
        <a href="<?php echo e(route('admin.banners.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">+ Thêm</a>
    </div>

    <table class="w-full table-auto border">
        <thead class="bg-gray-100">
            <tr>
                <th class="border px-2 py-2">#</th>
                <th class="border px-2 py-2">Ảnh</th>
                <th class="border px-2 py-2">Tiêu đề</th>
                <th class="border px-2 py-2">Link</th>
                <th class="border px-2 py-2">Vị trí</th>
                <th class="border px-2 py-2">Trạng thái</th>
                <th class="border px-2 py-2">Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border px-2 py-1 text-center"><?php echo e($index + 1); ?></td>
                    <td class="border px-2 py-1 text-center">
                        <img src="<?php echo e(asset('storage/' . $banner->image)); ?>" class="h-12 mx-auto">
                    </td>
                    <td class="border px-2 py-1"><?php echo e($banner->title); ?></td>
                    <td class="border px-2 py-1">
                        <a href="<?php echo e($banner->link); ?>" class="text-blue-600" target="_blank"><?php echo e($banner->link); ?></a>
                    </td>
                    <td class="border px-2 py-1 text-center"><?php echo e($banner->position); ?></td>
                    <td class="border px-2 py-1 text-center">
                        <?php if($banner->status): ?>
                            <span class="text-green-600 font-semibold">Hiển thị</span>
                        <?php else: ?>
                            <span class="text-gray-500 italic">Ẩn</span>
                        <?php endif; ?>
                    </td>
                    <td class="border px-2 py-1 text-center">
                        <a href="<?php echo e(route('admin.banners.edit', $banner->id)); ?>" class="text-blue-600">Sửa</a>
                        <form action="<?php echo e(route('admin.banners.destroy', $banner->id)); ?>" method="POST" class="inline-block ml-2"
                              onsubmit="return confirm('Bạn chắc chắn muốn xóa?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500">Xoá</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php else: ?>
<?php abort(403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HTML CSS VUEJS JS\PCluaga\resources\views\admin\banners\index.blade.php ENDPATH**/ ?>